package kgl;

import static org.junit.Assert.assertEquals;
import robocode.BattleResults;
import robocode.control.events.BattleCompletedEvent;
import robocode.control.testing.RobotTestBed;

/**
 * Java Test Case for Leonganisa Robot.
 * 
 * @author Kevin Leong
 * 
 */
public class TestLeonganisa extends RobotTestBed {

  @Override
  public String getRobotNames() {
    return "sample.SittingDuck,kgl.Leonganisa";
  }

  @Override
  public int getNumRounds() {
    return 10;
  }

  @Override
  public void onBattleCompleted(BattleCompletedEvent e) {
    BattleResults[] battleResults = e.getIndexedResults();

    assertEquals("Check Leonganisa Winner", battleResults[1].getFirsts(), this.getNumRounds());
  }
}
