package kgl;

import static robocode.util.Utils.normalRelativeAngleDegrees;
import java.awt.Color;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.Robot;
import robocode.Rules;
import robocode.ScannedRobotEvent;
import robocode.WinEvent;

/**
 * Competitive Robot created for ICS 413 tournament. This robot per the tournament rules only
 * extends the Robot class
 * 
 * @version 1.0
 * @author Kevin Leong
 * date September 16, 2010
 */

public class Leonganisa extends Robot {

  // Counter to keep track of how many turns have elapsed since
  // last enemy robot located
  int turnsElapsed = 0;

  // Tells the robot how much radar rotation is needed (degrees)
  double radarTurnAmount = 22.5;

  // The maximum distance
  double maxDistance;

  /**
   * Robot will execute these commands upon start.
   * 
   */
  public void run() {

    // Get battlefield dimensions and calculate maximum distance
    // (hypotenuse)
    double widthSquared = Math.pow(getBattleFieldWidth(), 2);
    double heightSquared = Math.pow(getBattleFieldHeight(), 2);
    maxDistance = Math.sqrt(widthSquared + heightSquared);

    // Set custom color
    Color customOrange = new Color(255, 100, 0);

    // Set Colors
    setBodyColor(customOrange);
    setGunColor(Color.white);
    setRadarColor(customOrange);
    setBulletColor(Color.orange);
    setScanColor(Color.orange);

    // Turn all components independently
    this.setAdjustGunForRobotTurn(true);
    this.setAdjustRadarForRobotTurn(true);
    this.setAdjustRadarForGunTurn(true);

    while (true) {
      turnRadarRight(radarTurnAmount);

      // With every turn, increment our counter
      turnsElapsed++;

      // If turns > 2 that robot hasn't found target, then continue to
      // rotate
      // radar to the left
      if (turnsElapsed > 1) {
        radarTurnAmount = -45;
      }

      // If robot hasn't found target in one turn, rotate maximum
      // scan arc to the left
      else if (turnsElapsed == 1) {
        radarTurnAmount = -45;
      }

    } // End while loop

  } // End Run

  /**
   * Robot will execute these commands upon scanning and finding an enemy robot.
   * 
   * @param e ScannedRobotEvent
   */
  public void onScannedRobot(ScannedRobotEvent e) {

    // Normalizing ensures we don't overturn
    // Find angle for gun and radar to turn to point at target
    double gunTurnAmount =
        normalRelativeAngleDegrees(e.getBearing() + getHeading() - getGunHeading());
    double radarTurnAmountToAlign =
        normalRelativeAngleDegrees(e.getBearing() + getHeading() - getRadarHeading());

    // turn gun towards target
    this.turnGunRight(gunTurnAmount);

    // realign radar
    this.turnRadarRight(radarTurnAmountToAlign);

    // Fire with firepower proportional to distance
    double firepower =
        (1 - e.getDistance() / maxDistance) * (Rules.MAX_BULLET_POWER - Rules.MIN_BULLET_POWER)
            + Rules.MIN_BULLET_POWER;

    this.fire(firepower);

    // Circle enemy if possible to avoid getting hit
    this.turnRight(e.getBearing() + 75);
    this.ahead(50);

    // reset time elapsed counter
    turnsElapsed = 0;

    // reset radar turning amount to initial arc size of 22.5 degrees
    radarTurnAmount = 22.5;

    this.scan();

  } // End onScannedRobot

  /**
   * Robot will execute these commands after hitting a wall.
   * 
   * @param e HitWallEvent
   */
  public void onHitWall(HitWallEvent e) {

    // Upon hitting a wall turn and move away from it
    this.turnRight(e.getBearing() - 45);
    this.back(120);

  }

  /**
   * Robot will execute these commands after getting hit by a bullet.
   * 
   * @param e HitByBullet
   */
  public void onHitByBullet(HitByBulletEvent e) {
    
    // Normalizing ensures we don't overturn
    // Find angle for gun and radar to turn to point at target
    double gunTurnAmount =
        normalRelativeAngleDegrees(e.getBearing() + getHeading() - getGunHeading());
    double radarTurnAmountToAlign =
        normalRelativeAngleDegrees(e.getBearing() + getHeading() - getRadarHeading());

    // turn gun towards target
    this.turnGunRight(gunTurnAmount);

    // realign radar
    this.turnRadarRight(radarTurnAmountToAlign);

    // Circle enemy if possible to avoid getting hit
    this.turnRight(e.getBearing() + 75);
    this.ahead(50);

    // reset time elapsed counter
    turnsElapsed = 0;

    // reset radar turning amount to initial arc size of 22.5 degrees
    radarTurnAmount = 22.5;

    this.scan();
  }

  /**
   * Robot will execute these commands after hitting another robot.
   * 
   * @param e HitRobotEvent
   */
  public void onHitRobot(HitRobotEvent e) {

    // Normalizing ensures we don't overturn
    // Find angle for gun and radar to turn to point at target
    double gunTurnAmount =
        normalRelativeAngleDegrees(e.getBearing() + getHeading() - getGunHeading());
    double radarTurnAmountToAlign =
        normalRelativeAngleDegrees(e.getBearing() + getHeading() - getRadarHeading());

    // turn gun and radar towards target
    this.turnGunRight(gunTurnAmount);
    this.turnRadarRight(radarTurnAmountToAlign);
    
    //Fire at full power and ram opponent
    fire(3);
    ahead(5);
  }

  /**
   * Robot will execute these commands upon winning.
   * 
   * @param e WinEvent
   */
  public void onWin(WinEvent e) {

    // Spin Everything
    while (true) {
      this.turnRight(10);
      this.turnGunRight(-20);
      this.turnRadarRight(45);
    }
  } // End onWin

} // End Class

